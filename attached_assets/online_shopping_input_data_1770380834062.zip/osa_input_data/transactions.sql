SELECT 
    TransactionKey,
    Customer_ID,
    Transaction_ID,
    Transaction_Date,
    Product_SKU,
    Quantity,
    Avg_Price,
    Delivery_Charges,
    Coupon_Status,
    GST,
    Date,
    Month,
    Coupon_Code,
    Discount_pct,
    CASE 
        WHEN Coupon_Code IS NOT NULL THEN 1 
        ELSE 0 
    END AS Clicked_Coupons,
    CASE 
        WHEN Coupon_Status = 'Used' THEN 1 
        ELSE 0 
    END AS Used_Coupons,

    -- total_units_sold
    COALESCE(Quantity, 0) AS total_units_sold,

    -- total_sales
    (COALESCE(Avg_Price, 0) * COALESCE(Quantity, 0)) AS total_sales,

    -- atv uses total_sales / count, so expose a row-level sales value
    (COALESCE(Avg_Price, 0) * COALESCE(Quantity, 0)) AS atv_sales_numerator,

    -- most_profitable_product is defined as quantity * avg_price 
    (COALESCE(Quantity, 0) * COALESCE(Avg_Price, 0)) AS most_profitable_product,

    CASE WHEN Coupon_Status = 'Used' THEN 1 ELSE 0 END AS count_used_coupons,

    -- average_discount_pct
    (COALESCE(Discount_pct, 0) / 100.0) AS average_discount_pct,

    -- percent of total calculations require window functions; expose row-level bases
    (COALESCE(Avg_Price, 0) * COALESCE(Quantity, 0)) AS percent_of_total_sales_base,
    COALESCE(Quantity, 0) AS percent_of_total_units_sold_base,

    -- total_used_coupons / total_clicked_coupons 
    CASE WHEN Coupon_Status = 'Used' THEN 1 ELSE 0 END AS total_used_coupons,
    CASE WHEN Coupon_Code IS NOT NULL THEN 1 ELSE 0 END AS total_clicked_coupons

FROM Transactions;