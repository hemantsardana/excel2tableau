SELECT 
    -- Customer columns
    C.Customer_ID,
    C.Gender,
    C.Location,
    C.Tenure_Months,
    C.Offline_Spend,
    C.Online_Spend,
    CASE
        WHEN C.Tenure_Months <= 12 THEN '0-12 months'
        WHEN C.Tenure_Months <= 24 THEN '13-24 months'
        WHEN C.Tenure_Months <= 36 THEN '25-36 months'
        ELSE 'Over 36 months'
    END AS Tenure_Range,
    
    -- Product columns
    P.Product_SKU,
    P.Product_Description,
    P.Product_Category,
    
    -- Transaction columns
    T.TransactionKey,
    T.Transaction_ID,
    T.Transaction_Date,
    T.Quantity,
    T.Avg_Price,
    T.Delivery_Charges,
    T.Coupon_Status,
    T.GST,
    T.Date,
    T.Month,
    T.Coupon_Code,
    T.Discount_pct,
    CASE 
        WHEN T.Coupon_Code IS NOT NULL THEN 1 
        ELSE 0 
    END AS Clicked_Coupons,
    CASE 
        WHEN T.Coupon_Status = 'Used' THEN 1 
        ELSE 0 
    END AS Used_Coupons
    
FROM Transactions T
INNER JOIN Customer C ON T.Customer_ID = C.Customer_ID
INNER JOIN Product P ON T.Product_SKU = P.Product_SKU;
