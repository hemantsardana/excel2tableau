SELECT 
    Product_SKU,
    Product_Description,
    Product_Category

    -- standardized keys/text
    UPPER(TRIM(Product_SKU)) AS product_sku_norm,

    TRIM(Product_Description) AS product_description_clean,

    TRIM(Product_Category) AS product_category_clean,

    -- filled / normalized category for easier grouping
    COALESCE(NULLIF(TRIM(Product_Category), ''), 'Uncategorized') AS product_category_filled,

    UPPER(COALESCE(NULLIF(TRIM(Product_Category), ''), 'UNCATEGORIZED')) AS product_category_norm,


    -- quality flags
    CASE WHEN Product_Description IS NULL OR TRIM(Product_Description) = '' THEN 1 ELSE 0 END AS is_missing_description,
    
    CASE WHEN Product_Category IS NULL OR TRIM(Product_Category) = '' THEN 1 ELSE 0 END AS is_missing_category,

    -- simple length features (useful for audits)
    LENGTH(TRIM(COALESCE(Product_Description, ''))) AS product_description_length,
    
    LENGTH(TRIM(COALESCE(Product_Category, ''))) AS product_category_length

FROM Product;