SELECT 
    Customer_ID,
    Gender,
    Location,
    Tenure_Months,
    Offline_Spend,
    Online_Spend,
    CASE
        WHEN Tenure_Months <= 12 THEN '0-12 months'
        WHEN Tenure_Months <= 24 THEN '13-24 months'
        WHEN Tenure_Months <= 36 THEN '25-36 months'
        ELSE 'Over 36 months'
    END AS Tenure_Range


    AVG(Offline_Spend) OVER () AS Average_Offline_Spend,

    AVG(Online_Spend)  OVER () AS Average_Online_Spend,

    AVG(Offline_Spend + Online_Spend) OVER () AS Average_Total_Spend,

    SUM(Offline_Spend) OVER () AS Total_Offline_Spend,

    SUM(Online_Spend)  OVER () AS Total_Online_Spend,

    SUM(Offline_Spend + Online_Spend) OVER () AS Total_Spend_All_Customers,

    COUNT(*) OVER () AS Customer_Count

    
FROM Customer;